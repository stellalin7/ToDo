package com.tts.ToDoListSolo.ToDo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class ToDo {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id; 
	private String title;
	private String description;
	private String creator;
	private String status;
			
	public ToDo() {
			
	}

	public ToDo(String title, String description, String creator, String status) {
		this.title = title;
		this.description = description;
		this.creator = creator;
		this.status = status;
	}

	public long getId() {
		return id;
	}


	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "ToDo [id=" + id + ", title=" + title + ", description=" + description + ", creator=" + creator
				+ ", status=" + status + "]";
	}	
}