package com.tts.ToDoListSolo.ToDo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;



@Controller
@RequestMapping
public class ToDoController {
	
	@Autowired
	private ToDoRepository toDoRepository; 
	
	@GetMapping(value = "/")
	public String index(ToDo toDo, Model model) {
		model.addAttribute("posts", toDoRepository.findAll());
	return "todo/index";
	}

	@GetMapping(value = "/todo/new")
	public String newList(ToDo toDo, Model model) {
		model.addAttribute("posts", toDoRepository.findAll());
	return "todo/new";
	}
	
	@PostMapping(value = "/todo/new")
	public String addNewToDoList(ToDo toDo, Model model) {
		toDoRepository.save(new ToDo(toDo.getTitle(), toDo.getDescription(), toDo.getCreator(), toDo.getStatus()));
		model.addAttribute("id", toDo.getId());
		model.addAttribute("title", toDo.getTitle());
		model.addAttribute("description", toDo.getDescription());
		model.addAttribute("creator", toDo.getCreator());
		model.addAttribute("status", toDo.getStatus());
	return "todo/result";
	 }
	
	@GetMapping(value="/todo/{id}")
	public String getListWithId(@PathVariable Long id, Model model) {
		ToDo toDo=toDoRepository.findById(id).orElse(null);
		model.addAttribute("posts", toDo);
	return "todo/show";
	}
	
	@GetMapping(value="/todo/delete/{id}")
	public String getListWithId2(@PathVariable Long id, Model model) {
		ToDo toDo=toDoRepository.findById(id).orElse(null);
		model.addAttribute("posts", toDo);
	return "todo/delete";
	}	
	
	@DeleteMapping(value="/todo/delete/{id}")
	public String deleteListWithId(@PathVariable Long id,Model model) {
		toDoRepository.deleteById(id);
		model.addAttribute("posts", toDoRepository.findAll());
	return "todo/index";
	}
	
	@GetMapping(value="/todo/update/{id}")
	public String updateListWithId(@PathVariable Long id, Model model) {
		ToDo toDo=toDoRepository.findById(id).orElse(null);
		model.addAttribute("posts", toDo);
	return "todo/update";
	}	
	
	@PutMapping(value="/todo/update/{id}")
	public String updateListWithId2(@PathVariable Long id, Model model, ToDo formData) {
		ToDo toDo=toDoRepository.findById(id).orElse(null);
			toDo.setTitle(formData.getTitle());
			toDo.setDescription(formData.getDescription());
			toDo.setCreator(formData.getCreator());
			toDo.setStatus(formData.getStatus());
		toDoRepository.save(toDo);
			model.addAttribute("id", toDo.getId());
			model.addAttribute("title", toDo.getTitle());
			model.addAttribute("description", toDo.getDescription());
			model.addAttribute("creator", toDo.getCreator());
			model.addAttribute("status", toDo.getStatus());
	return "todo/result";
	}
}

