package com.tts.ToDoListSolo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ToDoListSoloApplication {

	public static void main(String[] args) {
		SpringApplication.run(ToDoListSoloApplication.class, args);
	}

}
